import Homepage from "./Homepage";
import Blog from "../pages/Blog";

const App = () => {
  return (
    <div dir="rtl">
      <Homepage />
      <Blog />
    </div>
  );
};

export default App;
