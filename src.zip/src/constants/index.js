import images from "./images";

const constants = {
  images,
};

export default constants;
