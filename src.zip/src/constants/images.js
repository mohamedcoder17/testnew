import HeaderImg from "../assets/header.jpg";
import AboutImg from "../assets/about.jpg";
import BlogImgOne from "../assets/blog/01.jpg";
import BlogImgTwo from "../assets/blog/02.jpg";
import BlogImgThree from "../assets/blog/03.jpg";

const images = {
  HeaderImg,
  AboutImg,
  BlogImgOne,
  BlogImgTwo,
  BlogImgThree,
};

export default images;
